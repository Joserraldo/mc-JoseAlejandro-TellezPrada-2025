import tkinter as tk
from tkinter import messagebox
import re
from operar_enteros import OperarEnteros
from operar_flotantes import OperarFlotantes

class App:
    def __init__(self, root):
        self.root = root
        self.root.title("Proyecto Matemáticas Computacionales")
        self.root.geometry("600x450")
        
        self.entero_operador = OperarEnteros()
        self.flotante_operador = OperarFlotantes()
        
        self.titulo = tk.Label(self.root, text="Proyecto Matemáticas Computacionales", font=("Arial", 16, "bold"))
        self.titulo.pack(pady=10)
        
        self.frame = tk.Frame(self.root)
        self.frame.pack(pady=20)
        
        self.label = tk.Label(self.frame, text="Ingrese operación (ej. 4.5+5/2-8):")
        self.label.grid(row=0, column=0)
        
        self.entry = tk.Entry(self.frame, width=40)
        self.entry.grid(row=0, column=1)
        
        self.btn_calcular = tk.Button(self.frame, text="Calcular", command=self.calcular_operacion)
        self.btn_calcular.grid(row=1, column=0, columnspan=2, pady=10)
        
        self.label_resultado = tk.Label(self.frame, text="Resultado:")
        self.label_resultado.grid(row=2, column=0, columnspan=2)
        
        self.label_binario = tk.Label(self.frame, text="Binario:")
        self.label_binario.grid(row=3, column=0, columnspan=2)
        
        self.autores = tk.Label(self.root, text="Julian David Lizcano Manrique - U00180133\nJosé Alejandro Téllez Prada- U00060479", font=("Arial", 10))
        self.autores.pack(side=tk.BOTTOM, pady=10)
    
    def es_decimal(self, valor):
        """Determina si un valor es decimal o entero"""
        return isinstance(valor, float) or '.' in str(valor)
    
    def realizar_operacion(self, a, b, operador):
        """Realiza operación decidiendo entre enteros y flotantes"""
        # Convertir a float si alguno es decimal
        if self.es_decimal(a) or self.es_decimal(b):
            a = float(a)
            b = float(b)
            
            flotantes = OperarFlotantes([a, b])
            if operador == '*':
                resultado = flotantes.operar_todos('multiplicacion')
                return flotantes.formatear_flotante(resultado)
            elif operador == '/':
                resultado = flotantes.operar_todos('division')
                return flotantes.formatear_flotante(resultado)
        else:
            # Operación de enteros
            enteros = OperarEnteros([int(a), int(b)])
            if operador == '*':
                resultado = enteros.operar_todos('multiplicacion')
                return int(resultado, 2)
            elif operador == '/':
                resultado = enteros.operar_todos('division')
                return int(resultado, 2)
        
        # Para suma y resta
        return a * b if operador == '*' else a / b
    
    def calcular_operacion(self):
        try:
            # Obtener la expresión y eliminar espacios
            expresion_original = self.entry.get().replace(" ", "")
            
            # Validar que solo contenga números, puntos, comas y operadores básicos
            if not re.match(r'^[\d.,+\-*/]+$', expresion_original):
                raise ValueError("Formato inválido. Use solo números y operadores básicos.")
            
            # Reemplazar comas por puntos
            expresion = expresion_original.replace(",", ".")
            
            # Identificar operadores de multiplicación y división
            while re.search(r'[\d.]+[*/][\d.]+', expresion):
                # Encontrar primera coincidencia de multiplicación o división
                match = re.search(r'([\d.]+)([*/])([\d.]+)', expresion)
                if match:
                    numero1, operador, numero2 = match.groups()
                    
                    # Realizar operación
                    subresultado = self.realizar_operacion(numero1, numero2, operador)
                    
                    # Reemplazar la operación con su resultado
                    expresion = expresion.replace(match.group(0), str(subresultado))
            
            # Ahora resolver sumas y restas de izquierda a derecha
            # Usamos eval para este caso, ya que las multiplicaciones/divisiones ya fueron resueltas
            resultado = eval(expresion)
            
            # Convertir a binario según el tipo de resultado
            if isinstance(resultado, int):
                resultado_binario = self.entero_operador.convertir_a_binario(resultado)
            else:
                resultado_binario = self.flotante_operador.formatear_binario(
                    self.flotante_operador.convertir_a_binario(resultado)
                )
            
            # Mostrar resultados
            self.label_resultado.config(text=f"Resultado: {resultado}")
            self.label_binario.config(text=f"Binario: {resultado_binario}")
        
        except Exception as e:
            messagebox.showerror("Error", str(e))

if __name__ == "__main__":
    root = tk.Tk()
    app = App(root)
    root.mainloop()