#segundo taller
import random

def suma_matrices(A, B):
    if len(A) != len(B) or len(A[0]) != len(B[0]):
        raise ValueError("Las matrices deben tener las mismas dimensiones para sumar.")
    return [[A[i][j] + B[i][j] for j in range(len(A[0]))] for i in range(len(A))]

def multiplicacion_matrices(A, B):
    if len(A[0]) != len(B):
        raise ValueError("El número de columnas de A debe ser igual al número de filas de B para multiplicar.")

    resultado = []
    for i in range(len(A)):  
        fila_resultado = []
        for j in range(len(B[0])):  
            suma_producto = sum(A[i][k] * B[k][j] for k in range(len(B)))
            fila_resultado.append(suma_producto)
        resultado.append(fila_resultado)
    return resultado

def generar_matriz(filas, columnas):
    return [[random.randint(2, 8) for i in range(columnas)] for i in range(filas)]
while True:
    try:
        operacion = int(input("----------[EPICO GENERADOR DE SUMA O MULTIPLICACION DE MATRICES]----------\nDigite 1 para suma, 2 para multiplicación o 3 para salir: "))
        if operacion == 1:
            filas_A = columnas_A = random.randint(2, 8)
            filas_B = columnas_B = columnas_A
        elif operacion == 2:
            filas_A = random.randint(2, 8)
            columnas_A = random.randint(2, 8)
            filas_B = columnas_A
            columnas_B = random.randint(2, 8)
        elif operacion == 3:
            print("Saliendo del programa...")
            break
        else:
            print("Opción no válida. Intente nuevamente.")
            continue  # Si la opción no es válida, volver a pedir la entrada

        print(f"Generando dos matrices A y B con dimensiones:")
        print(f"Matriz A: {filas_A} x {columnas_A}")
        print(f"Matriz B: {filas_B} x {columnas_B}")

        A = generar_matriz(filas_A, columnas_A)
        B = generar_matriz(filas_B, columnas_B)

        print("\nMatriz A:")
        for fila in A:
            print(fila)
            
        print("\nMatriz B:")
        for fila in B:
            print(fila)

        if operacion == 1:

            if filas_A == filas_B and columnas_A == columnas_B:
                resultado_suma = suma_matrices(A, B)
                print("\nResultado de la suma de matrices:")
                for fila in resultado_suma:
                    print(fila)
            else:
                print("\nNo se pueden sumar las matrices, ya que tienen dimensiones diferentes.")

        elif operacion == 2:
            if columnas_A == filas_B:
                resultado_multiplicacion = multiplicacion_matrices(A, B)
                print("\nResultado de la multiplicación de matrices:")
                for fila in resultado_multiplicacion:
                    print(fila)
            else:
                print("\nNo se pueden multiplicar las matrices, ya que el número de columnas de A debe ser igual al número de filas de B.")

        else:
            print("Error, ingrese un valor correcto.")
    except Exception as e:
        print(f"Error: {e}")
