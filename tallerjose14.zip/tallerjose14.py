#primer taller
import random

def producto_escalar(v1,v2):
    return sum(a * b for a, b in zip(v1, v2))

def generar_matriz(n):
    vector_1 = [random.randint(1,10) for i in range(n)]
    vector_2 = [random.randint(1,10) for i in range(n)]
    print(f"Vector 1: {vector_1}")
    print(f"Vector 2: {vector_2}")
    return vector_1,vector_2



num_matriz = int(input("Escriba el numero de la matriz: "))
matriz = generar_matriz(num_matriz)
print(f"El producto escalar de los vectores es: {producto_escalar(matriz[0],matriz[1])}")